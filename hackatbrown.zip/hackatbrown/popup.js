console.log("Working");
s = ''
labelToAdd = '';

function doStuff(){
    console.log("clicked");


    appendToS = function(e) {
      if (xhr.readyState == 4 && xhr.status == 200) {
         var text = xhr.responseText;
         var idx = text.indexOf('Bamco.menu_items = ') + 19;
         var endIdx = text.indexOf('\n', idx) - 1;

         var exploring = JSON.parse(text.substring(idx, endIdx));
         var filter = document.getElementById('food').value.toUpperCase();

         var addedLabel = false;
         for(var key in exploring){
           foodLabel = exploring[key]['label'];
           if(foodLabel.toUpperCase().includes(filter)){
             if(!addedLabel){
               s += '</br><b>' + labelToAdd + '</b></br>'
               addedLabel = true;
             }
             s += foodLabel + '</br>';
           }
         }

      }
    }
    s = ''
    var arr = ['sharpe-refectory', 'andrews-commons', 'verney-woolley', 'blue-room', 'josiahs', 'ivy-room']
    var labelsToAdd = ['Ratty', 'Andrews', 'V-Dub', 'Blue Room', "Jo's", 'Ivy Room']

    document.getElementById('tmp').innerHTML = "About to send requests";

    for(var i = 0; i < arr.length; i++){
      var xhr = new XMLHttpRequest();
      labelToAdd = labelsToAdd[i];
      xhr.onreadystatechange = appendToS;
      xhr.open("GET", 'http://brown.cafebonappetit.com/cafe/' + arr[i] + '/', false);
      xhr.setRequestHeader('Content-type', 'text/html');
      xhr.send();
      document.getElementById('tmp').innerHTML = "Sent " + labelsToAdd[i];
    }

    document.getElementById('tmp').innerHTML = s;

    /*var foodtype = $("#food").val()
      $.get("http://localhost:8000/testcgi.py", function(data, status){
          document.getElementById('tmp').innerHTML = data;
          console.log(data);
      });*/
}

document.getElementById('food').onkeypress = function(e){
  if(e.keyCode == 13){
    doStuff();
  }
}
