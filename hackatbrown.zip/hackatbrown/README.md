# hackatbrown

#What if instead of just reading the menu from Brown, the chrome extension could ask you what school you go to and then it will find and parse the menu online for you, send alerts based on input of what food the user wants.

#Figure out how to save data: important for searching the menu to see if it matches the saved variable of "what they want to eat"
#Figure out how to make notifications appear on top of the chrome extension logo
#Figure out how to (IF BROWN API WORKS) parse through the data given by "all dishes ever served at the ratty", see when they are matched to the saved variable "what they want to eat"


